# HelloAbp
ABP vNext + vue-element-admin入门级项目实战

![](https://img2020.cnblogs.com/blog/610959/202009/610959-20200908130730771-106914331.png)

![](https://img2020.cnblogs.com/blog/610959/202009/610959-20200908130233951-268268971.png)

![](https://img2020.cnblogs.com/blog/610959/202009/610959-20200908130255277-1873811071.png)

![](https://img2020.cnblogs.com/blog/610959/202009/610959-20200908130343127-1874394158.png)

![](https://img2020.cnblogs.com/blog/610959/202009/610959-20200908130309406-801218160.png)

![](https://img2020.cnblogs.com/blog/610959/202009/610959-20200908130532749-1455178314.png)

![](https://img2020.cnblogs.com/blog/610959/202009/610959-20200908130604300-56478296.png)

![](https://img2020.cnblogs.com/blog/610959/202009/610959-20200908130623221-709687019.png)

![](https://img2020.cnblogs.com/blog/610959/202009/610959-20200908130854419-1350587737.png)

![](https://img2020.cnblogs.com/blog/610959/202009/610959-20200915115030501-533846903.png)

![](https://img2020.cnblogs.com/blog/610959/202009/610959-20200915115133845-1938144172.png)

![](https://img2020.cnblogs.com/blog/610959/202009/610959-20200915115229379-610140747.png)

# 运行

环境：.netcore 3.1、sqlserver、nodejs、npm

1. 运行/run/build.bat (编译模块、启动项目)
2. 修改Xhznl.HelloAbp.HttpApi.Host、Xhznl.HelloAbp.DbMigrator项目的数据库连接字符串
3. 运行/run/db-migrator.bat（初始化数据库、种子数据）
4. 运行/run/npm-install.bat（安装npm依赖）
5. 运行/run/run.bat

前3步只需执行一次。你也可以直接使用vs/vscode来运行

感谢@[jonny-xhl](https://github.com/jonny-xhl)贡献的代码

另一个干净的vue版本（只有abp启动模板中的功能）：https://github.com/xiajingren/ABP-vNext-Vue

----

还没做完。。。

欢迎关注我的微信公众号：**“小黑在哪里”** 查看abp vnext相关文章。
