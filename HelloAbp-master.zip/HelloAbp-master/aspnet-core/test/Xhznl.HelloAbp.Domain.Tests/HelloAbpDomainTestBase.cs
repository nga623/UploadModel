﻿namespace Xhznl.HelloAbp
{
    public abstract class HelloAbpDomainTestBase : HelloAbpTestBase<HelloAbpDomainTestModule> 
    {

    }
}
