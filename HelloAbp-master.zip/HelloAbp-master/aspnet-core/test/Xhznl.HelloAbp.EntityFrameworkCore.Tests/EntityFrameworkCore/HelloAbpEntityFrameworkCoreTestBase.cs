﻿using Volo.Abp;

namespace Xhznl.HelloAbp.EntityFrameworkCore
{
    public abstract class HelloAbpEntityFrameworkCoreTestBase : HelloAbpTestBase<HelloAbpEntityFrameworkCoreTestModule> 
    {

    }
}
