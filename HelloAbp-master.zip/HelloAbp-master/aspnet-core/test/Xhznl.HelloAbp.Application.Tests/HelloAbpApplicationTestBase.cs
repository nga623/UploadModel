﻿namespace Xhznl.HelloAbp
{
    public abstract class HelloAbpApplicationTestBase : HelloAbpTestBase<HelloAbpApplicationTestModule> 
    {

    }
}
