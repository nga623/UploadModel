using Volo.Abp.AspNetCore.Mvc.UI.RazorPages;

namespace Xhznl.FileManagement.Pages
{
    public class IndexModel : AbpPageModel
    {
        public void OnGet()
        {
        }
    }
}