﻿using Volo.Abp.Localization;

namespace Xhznl.FileManagement.Localization
{
    [LocalizationResourceName("FileManagement")]
    public class FileManagementResource
    {
        
    }
}
