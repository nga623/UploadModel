﻿namespace Xhznl.FileManagement
{
    public static class FileManagementErrorCodes
    {
        //Add your business exception error codes here...
    }
}
