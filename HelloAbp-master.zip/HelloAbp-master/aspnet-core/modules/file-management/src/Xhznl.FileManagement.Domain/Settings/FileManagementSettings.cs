﻿namespace Xhznl.FileManagement.Settings
{
    public static class FileManagementSettings
    {
        public const string GroupName = "FileManagement";

        /* Add constants for setting names. Example:
         * public const string MySettingName = GroupName + ".MySettingName";
         */

        public const string AllowedMaxFileSize = GroupName + ".AllowedMaxFileSize";
        public const string AllowedUploadFormats = GroupName + ".AllowedUploadFormats";
    }
}