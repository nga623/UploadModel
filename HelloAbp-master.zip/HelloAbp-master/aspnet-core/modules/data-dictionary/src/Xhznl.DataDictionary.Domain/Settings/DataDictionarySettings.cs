﻿namespace Xhznl.DataDictionary.Settings
{
    public static class DataDictionarySettings
    {
        public const string GroupName = "DataDictionary";

        /* Add constants for setting names. Example:
         * public const string MySettingName = GroupName + ".MySettingName";
         */
    }
}