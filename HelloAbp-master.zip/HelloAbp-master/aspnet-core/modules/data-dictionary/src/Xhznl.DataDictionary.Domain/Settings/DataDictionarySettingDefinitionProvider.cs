﻿using Volo.Abp.Settings;

namespace Xhznl.DataDictionary.Settings
{
    public class DataDictionarySettingDefinitionProvider : SettingDefinitionProvider
    {
        public override void Define(ISettingDefinitionContext context)
        {
            /* Define module settings here.
             * Use names from DataDictionarySettings class.
             */
        }
    }
}