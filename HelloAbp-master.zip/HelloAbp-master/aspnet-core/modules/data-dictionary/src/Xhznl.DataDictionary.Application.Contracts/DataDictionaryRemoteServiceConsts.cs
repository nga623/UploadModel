﻿namespace Xhznl.DataDictionary
{
    public class DataDictionaryRemoteServiceConsts
    {
        public const string RemoteServiceName = "AbpDataDictionary";
    }
}