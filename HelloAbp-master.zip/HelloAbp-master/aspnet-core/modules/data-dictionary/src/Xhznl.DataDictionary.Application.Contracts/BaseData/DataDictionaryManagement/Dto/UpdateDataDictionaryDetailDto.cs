﻿namespace Xhznl.DataDictionary.BaseData.DataDictionaryManagement.Dto
{
    public class UpdateDataDictionaryDetailDto:BaseCreateOrUpdateDataDictionaryDetailDto
    {
    }
}
