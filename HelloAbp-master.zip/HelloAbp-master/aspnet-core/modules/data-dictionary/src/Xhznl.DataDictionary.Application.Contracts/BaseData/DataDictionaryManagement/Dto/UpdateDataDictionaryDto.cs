﻿namespace Xhznl.DataDictionary.BaseData.DataDictionaryManagement.Dto
{
    public class UpdateDataDictionaryDto : BaseCreateOrUpdateDictionaryDto
    {
    }
}
