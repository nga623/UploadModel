﻿using System;

namespace Xhznl.DataDictionary.BaseData.DataDictionaryManagement.Dto
{
    public class CreateDataDictionaryDetailDto:BaseCreateOrUpdateDataDictionaryDetailDto
    {
        public CreateDataDictionaryDetailDto()
        {

        }
    }
}
