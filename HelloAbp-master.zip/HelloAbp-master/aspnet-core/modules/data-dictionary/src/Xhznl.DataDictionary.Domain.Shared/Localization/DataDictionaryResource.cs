﻿using Volo.Abp.Localization;

namespace Xhznl.DataDictionary.Localization
{
    [LocalizationResourceName("AbpDataDictionary")]
    public class DataDictionaryResource
    {
        
    }
}
