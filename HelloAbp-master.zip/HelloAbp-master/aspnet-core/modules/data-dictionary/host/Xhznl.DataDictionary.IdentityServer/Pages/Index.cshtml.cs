using Volo.Abp.AspNetCore.Mvc.UI.RazorPages;

namespace Xhznl.DataDictionary.Pages
{
    public class IndexModel : AbpPageModel
    {
        public void OnGet()
        {
        }
    }
}