﻿namespace Xhznl.HelloAbp
{
    public static class HelloAbpConsts
    {
        public const string DbTablePrefix = "App";

        public const string DbSchema = null;
    }
}
