﻿namespace Xhznl.HelloAbp.Settings
{
    public static class HelloAbpSettings
    {
        private const string Prefix = "HelloAbp";

        //Add your own setting names here. Example:
        //public const string MySetting1 = Prefix + ".MySetting1";
    }
}