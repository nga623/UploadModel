﻿namespace Xhznl.HelloAbp.Permissions
{
    public static class HelloAbpPermissions
    {
        public const string GroupName = "HelloAbp";

        //Add your own permission names. Example:
        //public const string MyPermission1 = GroupName + ".MyPermission1";
    }
}