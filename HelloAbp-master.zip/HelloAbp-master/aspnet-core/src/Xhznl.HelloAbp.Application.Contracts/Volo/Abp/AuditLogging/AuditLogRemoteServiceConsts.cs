﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Volo.Abp.AuditLogging
{
    public class AuditLogRemoteServiceConsts
    {
        public const string RemoteServiceName = "AuditLogging";
    }
}
