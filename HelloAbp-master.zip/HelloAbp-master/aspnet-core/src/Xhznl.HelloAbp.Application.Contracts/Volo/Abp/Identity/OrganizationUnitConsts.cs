﻿using System;
using System.Collections.Generic;
using System.Text;
using Volo.Abp.Identity;

namespace Xhznl.HelloAbp.Volo.Abp.Identity
{
    public static class HelloOrganizationUnitConsts
    {
        public static int MaxCodeLength { get; set; } = OrganizationUnitConsts.MaxCodeLength;
    }
}
