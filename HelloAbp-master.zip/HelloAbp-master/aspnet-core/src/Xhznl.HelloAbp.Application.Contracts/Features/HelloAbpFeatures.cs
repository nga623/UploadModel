﻿namespace Xhznl.HelloAbp.Features
{
    public class HelloAbpFeatures
    {
        public const string GroupName = "HelloAbp";

        public const string SocialLogins = GroupName + ".SocialLogins";
        public const string UserCount = GroupName + ".UserCount";
    }
}