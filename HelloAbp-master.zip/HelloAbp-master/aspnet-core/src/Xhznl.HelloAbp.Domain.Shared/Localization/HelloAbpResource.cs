﻿using Volo.Abp.Localization;

namespace Xhznl.HelloAbp.Localization
{
    [LocalizationResourceName("HelloAbp")]
    public class HelloAbpResource
    {

    }
}