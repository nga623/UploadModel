﻿namespace Xhznl.HelloAbp
{
    public static class HelloAbpDomainErrorCodes
    {
        /* You can add your business exception error codes here, as constants */
    }
}
